package cs362;

import java.io.Serializable;

public abstract class Label implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public abstract String toString();
}
